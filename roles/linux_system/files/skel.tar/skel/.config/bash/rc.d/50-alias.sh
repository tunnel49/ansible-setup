alias ls='ls --color=auto'
